#include <tos/task.hpp>
#include <tos/generator.hpp>