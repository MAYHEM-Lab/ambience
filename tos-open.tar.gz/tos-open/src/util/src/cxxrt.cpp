//
// Created by fatih on 5/17/18.
//

#include <tos/compiler.hpp>

extern "C" {
WEAK void __cxa_pure_virtual() {
}
}