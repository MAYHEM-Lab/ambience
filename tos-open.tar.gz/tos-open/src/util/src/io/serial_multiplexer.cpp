//
// Created by fatih on 3/14/20.
//

#include <tos/io/serial_multiplexer.hpp>