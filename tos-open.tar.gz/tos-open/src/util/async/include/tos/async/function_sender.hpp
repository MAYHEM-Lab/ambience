#pragma once

namespace tos::async {

    template <class FnT>
    auto function_sender(FnT&& fn) {
        
    }
}