#pragma once

namespace tos {
template <class T>
using out_ptr = T*;
}