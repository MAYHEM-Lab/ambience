//
// Created by fatih on 8/24/18.
//

#include <common/adxl345.hpp>