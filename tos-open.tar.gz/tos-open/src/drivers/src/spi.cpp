//
// Created by fatih on 4/23/18.
//

#include <common/spi.hpp>

namespace tos
{
    constexpr spi_mode::slave_t spi_mode::slave;
    constexpr spi_mode::master_t spi_mode::master;
}