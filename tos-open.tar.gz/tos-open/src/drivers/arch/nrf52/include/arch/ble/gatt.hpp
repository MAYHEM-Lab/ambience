//
// Created by fatih on 8/31/19.
//

#pragma once

#include "events.hpp"

namespace tos {
namespace nrf52 {
/**
 * This type manages the GATT services provided by the nRF52
 * Soft Device driver.
 */
class gatt {
public:
    gatt();

private:
};
} // namespace nrf52
} // namespace tos