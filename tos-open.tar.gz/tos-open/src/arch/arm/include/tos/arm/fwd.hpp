#pragma once

namespace tos::arm {
struct address_space;
}