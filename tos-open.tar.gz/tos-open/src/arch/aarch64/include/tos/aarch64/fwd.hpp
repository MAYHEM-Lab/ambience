#pragma once

namespace tos::aarch64 {
struct address_space;
}