#pragma once

namespace tos::x86_64 {
struct address_space;
}