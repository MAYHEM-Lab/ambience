#pragma once

#include <tos/debug/log.hpp>
#include <tos/flags.hpp>
#include <tos/x86_64/mmu/errors.hpp>
#include <tos/x86_64/mmu/common.hpp>

namespace tos::x86_64::detail {
} // namespace tos::x86_64::detail