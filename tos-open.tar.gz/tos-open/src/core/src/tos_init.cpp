//
// Created by fatih on 5/1/18.
//

#include <tos/ft.hpp>

namespace tos
{
}