//
// Created by Mehmet Fatih BAKIR on 25/03/2018.
//

#include <tos/print.hpp>
#include <stdlib.h>

namespace tos
{
}