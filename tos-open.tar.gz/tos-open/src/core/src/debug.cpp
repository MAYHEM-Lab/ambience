//
// Created by fatih on 8/27/18.
//

#include <tos/debug/debug.hpp>
#include <tos/debug/panic.hpp>
#include <tos/debug/stack_dump.hpp>