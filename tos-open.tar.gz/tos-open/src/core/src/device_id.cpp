//
// Created by fatih on 8/9/18.
//

#include <tos/compiler.hpp>
#include <tos/device_id.hpp>

WEAK tos::did::unique_id_t tos::did::unique_id = tos::did::undefined_id;