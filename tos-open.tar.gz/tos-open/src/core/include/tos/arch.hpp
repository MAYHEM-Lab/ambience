//
// Created by fatih on 4/16/18.
//

#pragma once

#include <tos/compiler.hpp>
#include <tos/core/arch.hpp>
#include <tos/core/arch_fwd.hpp>

namespace tos::arch {
using cur_arch::get_stack_ptr;
using cur_arch::set_stack_ptr;
} // namespace tos::arch