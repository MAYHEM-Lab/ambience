#pragma once

#include <tos/debug/trace/detail/registry.hpp>