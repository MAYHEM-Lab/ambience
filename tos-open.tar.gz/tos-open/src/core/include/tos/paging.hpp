#pragma once

#include <tos/paging/level_computation.hpp>
#include <tos/paging/physical_page_allocator.hpp>